import os
import http.server
import socketserver

# Set the IP adress and port for this server
ip = '0.0.0.0' #listen on all avaliable network inferences 
port = 8080 #Choosing a port

# Create a handler to serve files from current directory 
Handler = http.server.SimpleHTTPRequestHandler

# Create the server
httpd = socketserver.TCPServer((ip, int(port)), Handler)

#Start the server
print(f"serving at port {port}") # Print the port being used
httpd.serve_forever()